# MovieMuse

MovieMuse is a Django-based website that was made to help people find the best movies that suit themselves or their friends, while also allowing them to connect socially with other movie lovers.

How to run (on Windows): Launch command prompt, then execute the following two commands


cd (MovieMuse folder path)/mysite


py manage.py makemigrations


py manage.py migrate


py manage.py runserver


Created by Jacob Nelson, Alan Ribiev, Fardeen Khan, and Evan Pereira
